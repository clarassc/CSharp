﻿using System;

public class Exemplo_metodo
{
    public static void Main(String[] args)
    {
        int  resultado = ;


    }  

    public static int MaiorMenor(int n1, int n2)
    {
        
    }
}