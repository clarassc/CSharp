﻿using System;

public class Exemplo_metodo
{
    public static void Main(String[] args)
    {
        int resultado = MaiorMenor(10, 20);

            Console.WriteLine("O maior número dos " +
               "dois: " + resultado);
    }  

    public static int MaiorMenor(int n1, int n2)
    {
        if (n1 > n2)
        {
            return n1;
        }
        else
        {
            return n2;
        }
    }
}