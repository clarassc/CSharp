﻿using System;

public class Exercicio8
{
    public static void Main()
    {
        // Loop de 1 a 20
        for (int i = 1; i <= 20; i++)
        {
            // Verifica se o número é par
            if (i % 2 == 0)
            {
                Console.WriteLine(i);
            }
        }
    }
}
