﻿using System;

public class Exercicio5
{
    public static void Main()
    {
        // Solicita um número de 1 a 7
        Console.Write("Digite um número (1 a 7) para ver o dia da semana: ");
        int dia = int.Parse(Console.ReadLine()); // Lê e converte a entrada para número

        // Determina o dia da semana usando switch
        switch (dia)
        {
            case 1:
                Console.WriteLine("Domingo");
                break;
            case 2:
                Console.WriteLine("Segunda-feira");
                break;
            case 3:
                Console.WriteLine("Terça-feira");
                break;
            case 4:
                Console.WriteLine("Quarta-feira");
                break;
            case 5:
                Console.WriteLine("Quinta-feira");
                break;
            case 6:
                Console.WriteLine("Sexta-feira");
                break;
            case 7:
                Console.WriteLine("Sábado");
                break;
            default:
                Console.WriteLine("Número inválido! Introduza um número entre 1 e 7.");
                break;
        }
    }
}
