﻿using System;

public class Exercicio20
{
    public static void Main()
    {
        // N. Decimal para inteiro
        double numeroDecimal = 10.52;
        int decimalToInt = Convert.ToInt32(numeroDecimal);
        int decimalToCasting = (int)numeroDecimal;
        Console.WriteLine("Decimal: " + numeroDecimal + " To Integer: " + decimalToInt);
        Console.WriteLine("Decimal: " + numeroDecimal + " To Integer Casting: " + decimalToCasting);


        // N. Grande para pequeno
        long numeroMuitoLongo = 123456789012345;
        //int longToIntConvert = Convert.ToInt32(numeroMuitoLongo);
        int longToInt = (int)numeroMuitoLongo;
        //Console.WriteLine("Long: " + numeroMuitoLongo + " To Integer: " + longToIntConvert);
        Console.WriteLine("Long: " + numeroMuitoLongo + " To Integer Casting: " + longToInt);


        //Char para ASCII (int)
        char letra = 'B';
        int numeroAsciiCasting = (int)letra;
        int numeroAsciiConvert = Convert.ToInt32(letra);
        Console.WriteLine("Character: " + letra + " To Int ASCII Casting: " + numeroAsciiCasting);
        Console.WriteLine("Character: " + letra + " To Int ASCII Convert: " + numeroAsciiConvert);


        // Numero fora do intervalo do byte para byte
        int numeroInt = 282;
        byte numeroByteCasting = (byte)numeroInt;
        //byte numeroByteConvert = Convert.ToByte(numeroInt);
        Console.WriteLine("Integer: " + numeroInt + " To Byte Casting: " + numeroByteCasting);
        //Console.WriteLine("Integer: " + numeroInt + " To Byte Convert: " + numeroByteConvert);


        // Decimal (double) para float
        double numeroDouble = 1234.56789123456789;
        float numeroFloatCasting = (float)numeroDouble;
        float numeroFloatConvert = Convert.ToSingle(numeroDouble);
        Console.WriteLine("Double: " + numeroDouble + " To Float Casting: " + numeroFloatCasting);
        Console.WriteLine("Double: " + numeroDouble + " To Float Convert: " + numeroFloatConvert);
    }
}